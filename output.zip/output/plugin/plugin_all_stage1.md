# Plug-in study (suite plugin_all), stage 1 and PEMS04/08: evaluation (2026-11-14)

**Source.** [`plugin_all_stage1.tsv`](plugin_all_stage1.tsv): 515 records from the RTX 4090 (PyTorch
2.10.0+cu130), seed 2021, no failed run:
- all 384 runs of stage 1: ETTh1, ETTh2, ETTm1, ETTm2, Exchange and Weather, horizons 96 to 720;
- all 128 runs on PEMS04/08, horizons 12 to 96, with the protocol of iTransformer and S-Mamba;
- the first 3 Electricity runs, which are not evaluated here.

Every setting has both arms: 8 backbones alone and with the DLT-dyn branch (default recipe: k 8, L 48, R 4, branch
learning rate 3e-3). The tables below are from
`python scripts/plugin/plugin_table.py --files output/plugin/plugin_all_stage1.tsv`; add `--metric mae` for MAE.
One seed: changes below about 2 % are within the seed spread of the earlier three-seed CPU runs.

## The set-up is sound
- **Backbones alone reproduce the published numbers** (input 96, MSE, `assets/reported.json`):

  | backbone | mean gap | within 5 % | largest gap |
  |---|---:|---:|---|
  | S-Mamba | +0.3 % | 24 of 24 | ETTh1-720 +1.8 % |
  | iTransformer | +0.6 % | 24 of 24 | Exchange-192 +3.7 % |
  | DLinear | +0.6 % | 21 of 24 | Exchange-720 −10.7 % |
  | TimesNet | +1.2 % | 17 of 24 | ETTm1-336 +8.4 % |
  | TimeMixer | +1.8 % | 20 of 24 | Exchange-96 +11.5 % |
  | PatchTST | +5.3 % | 14 of 24 | ETTm1-192 +19.8 % |

  PatchTST uses its paper's small setting on ETT with the TSLib training budget. Informer and TimeXer have no
  numbers in `reported.json`.
- **GPU agrees with CPU.** The six settings also run on the CPU in P1 (three seeds) show the same changes:

  | setting | DLinear | PatchTST | iTransformer |
  |---|---:|---:|---:|
  | Weather-96, CPU / GPU | −17.3 % / −16.9 % | −9.1 % / −10.9 % | −6.7 % / −7.3 % |
  | ETTh1-96, CPU / GPU | +2.2 % / +0.7 % | −2.6 % / −4.0 % | +2.9 % / +1.7 % |

## What is as expected, and what is not
Change of the test MSE by the branch, mean over settings (share of settings where the branch helps):

| backbones | Weather, PEMS04, PEMS08 | ETTh1/h2/m1/m2, Exchange |
|---|---:|---:|
| channel-independent: DLinear, PatchTST | −31.8 % (24 of 24) | +4.3 % (16 of 40) |
| variable-mixing: TimesNet, iTransformer, TimeMixer, TimeXer, S-Mamba | −5.8 % (44 of 60) | +8.0 % (15 of 100) |
| Informer | −11.0 % (10 of 12) | −3.9 % (12 of 20) |

**As expected.**
- Where the variables lead and lag each other (meteorology, neighbouring road sensors), the branch helps.
- The gain is largest for the backbones that see each variable alone: DLinear −46 % and −48 % on PEMS04/08,
  PatchTST −47 % and −37 %.

**Not as hoped.**
- On ETTh2 (median +9.5 %) and Exchange (median +14.0 %, up to +45 % for S-Mamba) the branch hurts almost every
  backbone. On ETTh1 it costs about 2 %; ETTm1 and ETTm2 are neutral.
- TimeMixer and TimeXer gain nowhere: the branch helps in 6 and 4 of 32 settings.
- Informer's gains do not speak for the branch. Informer alone is far behind the other backbones (ETTh1 MSE
  0.95 to 1.17, ETTh2 3.0 to 6.3), so any added linear component helps it.

## Why
1. **The datasets.** The stand-alone study (P1, CPU, three seeds) had already measured where cross-variable lags
   help. There, DLT-dyn was compared with the same model without the cross branch (CI linear), average MSE over
   the four horizons. The plug-in study ranks the six datasets identically (Spearman 1.0):

   | dataset | stand-alone: DLT-dyn vs CI linear | plug-in: median change |
   |---|---:|---:|
   | Exchange | +52.4 % | +14.0 % |
   | ETTh2 | +12.5 % | +9.5 % |
   | ETTh1 | +4.2 % | +2.0 % |
   | ETTm2 | +0.3 % | +0.7 % |
   | ETTm1 | −2.7 % | +0.6 % |
   | Weather | −8.5 % | −3.6 % |

   ETT and Exchange have 7 and 8 variables, so k = 8 means every other variable is a neighbour and nothing is
   selected. Their lead-lag relations are weak or change over time. Even the tuned stand-alone model stayed
   behind CI linear on both (P1: Exchange 0.482 vs 0.353, ETTh2 0.395 vs 0.377).
2. **The training recipe makes it worse.** The branch adds its full correction from the first step and learns 30
   times faster than most backbones (3e-3 against 1e-4). On the datasets where it hurts, the + DLT arm reaches its
   best validation loss after one or two epochs: ETTh1 1.6 instead of 4.4, ETTh2 2.4 instead of 4.5, Exchange 1.8
   instead of 3.4. Early stopping then keeps a backbone that has trained for one or two epochs, for example
   PatchTST on Exchange (best epoch 6.8 alone, 1.0 with the branch, +27 %).

   This is not a validation/test mismatch. The validation loss of the + DLT arm is worse too (ETTh2 +8.0 %,
   Exchange +12.9 %); only 2 of 32 settings on each of ETTh1 and ETTh2 improve on validation but not on test.
   Exchange has 9 of 32, so it also has a shift between periods. On Weather and PEMS the best epoch does not move
   (4.3 / 4.3; 8.7 / 9.2; 6.5 / 8.2).

   The recipe does not explain everything: iTransformer on ETTh2 stops at the same epoch (3.2) and still loses
   11 %. Across all ETT/Exchange settings the shift of the best epoch and the loss correlate only weakly
   (Spearman −0.11).
3. **Backbones that already mix variables gain less.** TimeXer attends across variables, and TimeMixer mixes
   them on PEMS (`--channel_independence 0`), so the branch adds little information but still adds variance.

## Next
- **Recipe probe on the datasets where the branch hurts**, with Weather as the positive control: a static gate
  (the branch starts at 4.7 % strength), `--dlt "--dlt_gate static"`, as a separate arm. If it removes the harm
  and keeps the gains, it becomes the default recipe. All + DLT arms would then be re-run with it.
- **TimeMixer on PEMS04/08** ran with patience 3, before its complete official PEMS setting (patience 10) was
  added; re-run these 16 jobs.
- **Remaining datasets:** Solar, PEMS03, PEMS07, Electricity and Traffic.

---

## Tables: backbone alone vs + DLT-dyn (arm `dlt`)

Suite `plugin_all`, seed(s) 2021; 256 settings with both arms. Metric: MSE (PEMS: normalised scale). Change = (+ DLT) / alone - 1; **bold**: the branch helps.

### 1. Change of MSE, averaged over the horizons

| dataset | Informer | TimesNet | DLinear | PatchTST | iTransformer | TimeMixer | TimeXer | S-Mamba |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ETTh1 | **-23.4 %** | +0.2 % | +2.5 % | **-0.8 %** | +4.2 % | +3.4 % | +4.0 % | +2.8 % |
| ETTh2 | **-13.0 %** | +5.1 % | **-0.9 %** | +14.1 % | +11.2 % | +10.1 % | +5.4 % | +14.4 % |
| ETTm1 | **-12.6 %** | +6.0 % | +1.2 % | **-8.4 %** | **-0.2 %** | +2.6 % | +5.7 % | +3.2 % |
| ETTm2 | +7.4 % | +1.4 % | +1.0 % | +0.2 % | **-0.5 %** | +1.3 % | +4.9 % | +0.8 % |
| Exchange | +5.1 % | +12.3 % | +10.0 % | +38.7 % | +32.0 % | +27.1 % | +36.7 % | +44.8 % |
| Weather | **-5.3 %** | **-4.8 %** | **-9.8 %** | **-6.7 %** | **-4.7 %** | **-0.1 %** | +1.1 % | **-2.2 %** |
| PEMS04 | **-9.0 %** | **-14.4 %** | **-46.4 %** | **-46.7 %** | **-12.3 %** | +1.6 % | +1.0 % | **-2.8 %** |
| PEMS08 | **-22.1 %** | **-16.2 %** | **-48.1 %** | **-36.7 %** | **-31.3 %** | **-1.9 %** | +0.9 % | **-7.8 %** |
| mean | -9.1 % | -1.3 % | -11.3 % | -5.8 % | -0.2 % | +5.5 % | +7.5 % | +6.7 % |

### 2. MSE of the backbone alone / + DLT-dyn (change)

| dataset | H | Informer | TimesNet | DLinear | PatchTST | iTransformer | TimeMixer | TimeXer | S-Mamba |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ETTh1 | 96 | **0.952 / 0.632 (-33.6 %)** | 0.389 / 0.408 (+4.8 %) | 0.400 / 0.403 (+0.7 %) | **0.427 / 0.410 (-4.0 %)** | 0.386 / 0.392 (+1.7 %) | 0.379 / 0.416 (+9.8 %) | 0.387 / 0.403 (+4.2 %) | 0.389 / 0.404 (+3.9 %) |
| ETTh1 | 192 | **1.018 / 0.701 (-31.1 %)** | 0.439 / 0.465 (+6.0 %) | 0.446 / 0.455 (+1.9 %) | **0.472 / 0.453 (-4.1 %)** | 0.440 / 0.482 (+9.4 %) | 0.423 / 0.436 (+3.1 %) | 0.431 / 0.457 (+6.1 %) | 0.445 / 0.461 (+3.8 %) |
| ETTh1 | 336 | **1.033 / 0.909 (-12.0 %)** | **0.522 / 0.495 (-5.1 %)** | 0.487 / 0.501 (+2.8 %) | **0.509 / 0.508 (-0.3 %)** | 0.487 / 0.496 (+1.7 %) | **0.500 / 0.495 (-1.0 %)** | 0.474 / 0.500 (+5.4 %) | 0.491 / 0.500 (+1.9 %) |
| ETTh1 | 720 | **1.168 / 0.955 (-18.3 %)** | **0.521 / 0.507 (-2.6 %)** | 0.520 / 0.541 (+4.0 %) | 0.507 / 0.530 (+4.4 %) | 0.501 / 0.521 (+4.0 %) | 0.477 / 0.492 (+3.1 %) | 0.501 / 0.505 (+0.7 %) | 0.511 / 0.522 (+2.1 %) |
| ETTh2 | 96 | 2.988 / 3.394 (+13.6 %) | 0.333 / 0.336 (+1.1 %) | 0.351 / 0.363 (+3.3 %) | 0.303 / 0.389 (+28.5 %) | 0.300 / 0.337 (+12.3 %) | 0.283 / 0.362 (+28.0 %) | 0.286 / 0.320 (+12.2 %) | 0.296 / 0.355 (+19.8 %) |
| ETTh2 | 192 | **6.252 / 4.363 (-30.2 %)** | 0.407 / 0.439 (+7.8 %) | 0.481 / 0.493 (+2.6 %) | 0.389 / 0.431 (+10.7 %) | 0.380 / 0.433 (+14.0 %) | 0.398 / 0.410 (+3.1 %) | 0.363 / 0.408 (+12.4 %) | 0.378 / 0.433 (+14.6 %) |
| ETTh2 | 336 | **5.625 / 5.157 (-8.3 %)** | 0.457 / 0.458 (+0.2 %) | **0.594 / 0.563 (-5.2 %)** | 0.426 / 0.476 (+11.9 %) | 0.422 / 0.473 (+12.0 %) | 0.415 / 0.456 (+9.9 %) | 0.416 / 0.429 (+3.1 %) | 0.422 / 0.475 (+12.6 %) |
| ETTh2 | 720 | **4.202 / 3.673 (-12.6 %)** | 0.433 / 0.479 (+10.7 %) | **0.819 / 0.805 (-1.6 %)** | 0.428 / 0.468 (+9.2 %) | 0.431 / 0.462 (+7.2 %) | 0.432 / 0.454 (+5.1 %) | **0.450 / 0.438 (-2.5 %)** | 0.428 / 0.481 (+12.3 %) |
| ETTm1 | 96 | **0.752 / 0.532 (-29.2 %)** | 0.336 / 0.348 (+3.4 %) | **0.345 / 0.332 (-3.9 %)** | **0.376 / 0.351 (-6.6 %)** | **0.341 / 0.328 (-4.0 %)** | 0.319 / 0.324 (+1.3 %) | 0.318 / 0.322 (+1.1 %) | **0.331 / 0.328 (-1.2 %)** |
| ETTm1 | 192 | **0.741 / 0.693 (-6.5 %)** | **0.388 / 0.387 (-0.4 %)** | 0.382 / 0.384 (+0.6 %) | **0.440 / 0.386 (-12.3 %)** | **0.380 / 0.379 (-0.3 %)** | 0.366 / 0.367 (+0.3 %) | 0.362 / 0.371 (+2.3 %) | 0.377 / 0.380 (+0.7 %) |
| ETTm1 | 336 | **1.160 / 1.115 (-3.9 %)** | 0.444 / 0.476 (+7.2 %) | 0.413 / 0.421 (+1.9 %) | **0.466 / 0.425 (-8.9 %)** | **0.424 / 0.418 (-1.4 %)** | 0.393 / 0.401 (+2.1 %) | 0.394 / 0.427 (+8.2 %) | 0.409 / 0.437 (+6.9 %) |
| ETTm1 | 720 | **1.017 / 0.869 (-14.5 %)** | 0.478 / 0.536 (+12.0 %) | 0.474 / 0.497 (+5.0 %) | **0.516 / 0.486 (-5.8 %)** | 0.485 / 0.504 (+3.7 %) | 0.455 / 0.481 (+5.7 %) | 0.453 / 0.496 (+9.5 %) | 0.473 / 0.498 (+5.1 %) |
| ETTm2 | 96 | 0.408 / 0.809 (+98.5 %) | 0.188 / 0.201 (+6.8 %) | **0.197 / 0.189 (-3.7 %)** | 0.187 / 0.188 (+0.6 %) | **0.183 / 0.182 (-0.4 %)** | 0.175 / 0.179 (+1.8 %) | 0.172 / 0.198 (+15.4 %) | 0.179 / 0.179 (+0.0 %) |
| ETTm2 | 192 | **0.842 / 0.574 (-31.8 %)** | 0.255 / 0.255 (+0.2 %) | **0.278 / 0.272 (-2.0 %)** | **0.255 / 0.254 (-0.4 %)** | **0.253 / 0.247 (-2.2 %)** | 0.239 / 0.242 (+1.0 %) | 0.237 / 0.242 (+2.3 %) | **0.252 / 0.248 (-1.5 %)** |
| ETTm2 | 336 | 1.481 / 1.725 (+16.4 %) | 0.316 / 0.320 (+1.2 %) | **0.369 / 0.356 (-3.5 %)** | 0.310 / 0.313 (+0.8 %) | 0.315 / 0.316 (+0.6 %) | 0.297 / 0.301 (+1.1 %) | 0.297 / 0.310 (+4.5 %) | 0.312 / 0.312 (+0.2 %) |
| ETTm2 | 720 | 3.480 / 3.560 (+2.3 %) | **0.423 / 0.422 (-0.2 %)** | 0.541 / 0.581 (+7.4 %) | **0.414 / 0.414 (-0.0 %)** | **0.412 / 0.411 (-0.2 %)** | 0.398 / 0.405 (+1.5 %) | 0.392 / 0.401 (+2.2 %) | 0.413 / 0.425 (+3.0 %) |
| Exchange | 96 | 0.923 / 1.044 (+13.1 %) | 0.114 / 0.122 (+6.7 %) | **0.095 / 0.094 (-0.6 %)** | 0.094 / 0.108 (+14.8 %) | 0.087 / 0.101 (+16.1 %) | 0.095 / 0.108 (+13.9 %) | 0.090 / 0.115 (+27.2 %) | 0.087 / 0.108 (+24.7 %) |
| Exchange | 192 | 1.076 / 1.103 (+2.5 %) | **0.211 / 0.208 (-1.3 %)** | 0.182 / 0.197 (+8.6 %) | 0.189 / 0.211 (+11.3 %) | 0.184 / 0.198 (+7.7 %) | 0.176 / 0.203 (+15.3 %) | 0.188 / 0.217 (+15.2 %) | 0.181 / 0.207 (+14.1 %) |
| Exchange | 336 | 1.634 / 1.648 (+0.9 %) | 0.359 / 0.396 (+10.3 %) | 0.327 / 0.361 (+10.3 %) | 0.343 / 0.450 (+31.3 %) | 0.328 / 0.392 (+19.6 %) | 0.382 / 0.400 (+4.7 %) | 0.371 / 0.412 (+11.0 %) | 0.330 / 0.482 (+45.8 %) |
| Exchange | 720 | 2.823 / 2.989 (+5.9 %) | 1.015 / 1.182 (+16.5 %) | 0.749 / 0.835 (+11.5 %) | 0.866 / 1.302 (+50.3 %) | 0.861 / 1.235 (+43.5 %) | 0.940 / 1.313 (+39.7 %) | 0.867 / 1.329 (+53.2 %) | 0.858 / 1.312 (+52.9 %) |
| Weather | 96 | 0.367 / 0.446 (+21.6 %) | **0.170 / 0.160 (-6.1 %)** | **0.195 / 0.162 (-16.9 %)** | **0.186 / 0.166 (-10.9 %)** | **0.175 / 0.162 (-7.3 %)** | **0.164 / 0.158 (-3.3 %)** | 0.157 / 0.159 (+1.1 %) | **0.167 / 0.161 (-3.9 %)** |
| Weather | 192 | **0.541 / 0.443 (-18.1 %)** | **0.235 / 0.214 (-8.9 %)** | **0.237 / 0.204 (-13.8 %)** | **0.232 / 0.211 (-9.0 %)** | **0.225 / 0.212 (-5.9 %)** | 0.208 / 0.208 (+0.0 %) | 0.204 / 0.205 (+0.8 %) | **0.216 / 0.212 (-2.1 %)** |
| Weather | 336 | 0.621 / 0.636 (+2.3 %) | **0.284 / 0.272 (-4.1 %)** | **0.282 / 0.260 (-7.6 %)** | **0.287 / 0.267 (-7.0 %)** | **0.282 / 0.269 (-4.6 %)** | 0.264 / 0.265 (+0.4 %) | 0.262 / 0.264 (+0.8 %) | **0.277 / 0.269 (-2.7 %)** |
| Weather | 720 | **1.206 / 1.064 (-11.8 %)** | **0.359 / 0.351 (-2.1 %)** | **0.346 / 0.329 (-4.8 %)** | **0.361 / 0.351 (-2.7 %)** | **0.360 / 0.349 (-2.9 %)** | 0.344 / 0.348 (+1.1 %) | 0.342 / 0.347 (+1.6 %) | **0.352 / 0.348 (-1.1 %)** |
| ECL | 96 |  | + DLT only |  |  |  |  |  |  |
| ECL | 192 |  | + DLT only |  |  |  |  |  |  |
| ECL | 336 |  | + DLT only |  |  |  |  |  |  |
| PEMS04 | 12 | **0.114 / 0.094 (-17.4 %)** | **0.089 / 0.074 (-17.1 %)** | **0.146 / 0.084 (-42.1 %)** | **0.141 / 0.089 (-36.6 %)** | **0.081 / 0.075 (-7.5 %)** | 0.068 / 0.070 (+1.9 %) | **0.077 / 0.077 (-0.8 %)** | **0.073 / 0.072 (-1.3 %)** |
| PEMS04 | 24 | **0.117 / 0.104 (-11.5 %)** | **0.108 / 0.092 (-15.0 %)** | **0.222 / 0.114 (-48.5 %)** | **0.221 / 0.129 (-41.9 %)** | **0.100 / 0.089 (-10.9 %)** | 0.081 / 0.081 (+0.3 %) | 0.094 / 0.094 (+0.2 %) | **0.084 / 0.082 (-1.8 %)** |
| PEMS04 | 48 | **0.124 / 0.116 (-6.5 %)** | **0.149 / 0.125 (-16.0 %)** | **0.351 / 0.177 (-49.5 %)** | **0.420 / 0.229 (-45.5 %)** | **0.131 / 0.114 (-13.0 %)** | **0.095 / 0.092 (-2.9 %)** | 0.128 / 0.130 (+1.3 %) | **0.104 / 0.101 (-2.1 %)** |
| PEMS04 | 96 | **0.126 / 0.124 (-1.4 %)** | **0.196 / 0.173 (-11.5 %)** | **0.447 / 0.249 (-44.3 %)** | **0.795 / 0.395 (-50.4 %)** | **0.173 / 0.147 (-14.9 %)** | 0.109 / 0.116 (+6.2 %) | 0.177 / 0.180 (+1.9 %) | **0.125 / 0.118 (-5.1 %)** |
| PEMS08 | 12 | **0.310 / 0.235 (-24.3 %)** | **0.120 / 0.082 (-31.2 %)** | **0.154 / 0.087 (-43.4 %)** | **0.140 / 0.090 (-35.6 %)** | **0.087 / 0.081 (-6.4 %)** | **0.075 / 0.075 (-0.7 %)** | **0.084 / 0.080 (-5.1 %)** | **0.077 / 0.075 (-1.8 %)** |
| PEMS08 | 24 | **0.353 / 0.269 (-23.8 %)** | **0.151 / 0.114 (-24.9 %)** | **0.249 / 0.128 (-48.7 %)** | **0.211 / 0.144 (-32.0 %)** | **0.133 / 0.120 (-9.2 %)** | 0.095 / 0.096 (+0.8 %) | **0.115 / 0.111 (-3.0 %)** | **0.106 / 0.103 (-3.2 %)** |
| PEMS08 | 48 | **0.459 / 0.328 (-28.4 %)** | **0.213 / 0.177 (-17.1 %)** | **0.446 / 0.215 (-51.8 %)** | **0.413 / 0.270 (-34.8 %)** | **0.263 / 0.219 (-16.7 %)** | **0.138 / 0.137 (-0.5 %)** | 0.176 / 0.179 (+1.8 %) | **0.161 / 0.145 (-9.9 %)** |
| PEMS08 | 96 | **0.461 / 0.400 (-13.1 %)** | **0.337 / 0.316 (-6.4 %)** | **0.692 / 0.370 (-46.5 %)** | **0.872 / 0.532 (-38.9 %)** | **0.493 / 0.249 (-49.4 %)** | **0.210 / 0.200 (-4.5 %)** | 0.302 / 0.313 (+3.6 %) | **0.277 / 0.249 (-9.9 %)** |

### 3. Per backbone

| backbone | settings | branch helps (MSE) | mean / median change MSE | mean change MAE | epochs alone / + DLT | best epoch alone / + DLT |
|---|---:|---:|---:|---:|---:|---:|
| Informer | 32 | 22 of 32 | -6.6 % / -11.6 % | -3.9 % | 5.7 / 6.1 | 2.9 / 3.2 |
| TimesNet | 32 | 17 of 32 | -2.3 % / -0.3 % | -1.7 % | 6.0 / 5.6 | 4.2 / 3.8 |
| DLinear | 32 | 19 of 32 | -11.8 % / -2.8 % | -8.1 % | 7.7 / 7.5 | 5.6 / 5.1 |
| PatchTST | 32 | 21 of 32 | -6.7 % / -4.0 % | -5.1 % | 8.1 / 6.1 | 6.3 / 4.3 |
| iTransformer | 32 | 18 of 32 | -0.1 % / -0.4 % | -0.4 % | 7.7 / 6.8 | 5.3 / 4.4 |
| TimeMixer | 32 | 6 of 32 | +4.6 % / +1.6 % | +2.0 % | 8.3 / 8.2 | 4.5 / 4.2 |
| TimeXer | 32 | 4 of 32 | +6.2 % / +2.3 % | +1.7 % | 7.1 / 7.1 | 4.7 / 4.8 |
| S-Mamba | 32 | 14 of 32 | +5.5 % / +0.4 % | +2.5 % | 8.1 / 6.7 | 6.3 / 4.5 |

### 4. Per dataset: test vs validation, early stopping

| dataset | settings | branch helps | median change test | median change validation | validation better, test worse | best epoch alone / + DLT |
|---|---:|---:|---:|---:|---:|---:|
| ETTh1 | 32 | 10 of 32 | +2.0 % | +1.8 % | 2 of 32 | 4.4 / 1.6 |
| ETTh2 | 32 | 6 of 32 | +9.5 % | +8.0 % | 2 of 32 | 4.5 / 2.4 |
| ETTm1 | 32 | 14 of 32 | +0.6 % | -1.0 % | 11 of 32 | 4.7 / 4.7 |
| ETTm2 | 32 | 11 of 32 | +0.7 % | +0.8 % | 7 of 32 | 3.3 / 2.2 |
| Exchange | 32 | 2 of 32 | +14.0 % | +12.9 % | 9 of 32 | 3.4 / 1.8 |
| Weather | 32 | 23 of 32 | -3.6 % | -2.7 % | 3 of 32 | 4.3 / 4.3 |
| PEMS04 | 32 | 26 of 32 | -11.2 % | -12.1 % | 3 of 32 | 8.7 / 9.2 |
| PEMS08 | 32 | 29 of 32 | -14.9 % | -15.7 % | 1 of 32 | 6.5 / 8.2 |

